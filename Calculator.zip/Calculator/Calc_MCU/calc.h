/*
 * calc.h
 *
 *  Created on: Aug 30, 2019
 *      Author: abdel_000
 */

#ifndef CALC_H_
#define CALC_H_

#define MAX_OPERANDS 			20
#define MAX_OPERATIONS 			39
#define MAX_NEGATIVE_SIGNS_POSSIBLE			39

void calculator(void);

#endif /* CALC_H_ */
